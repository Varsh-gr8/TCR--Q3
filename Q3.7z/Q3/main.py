from mammal import Mammal
from bird import Bird

def main():
    m = Mammal("Elephant", 25, False, "Grey")
    b = Bird("Parrot", 2, False, True)

    print(m.make_sound())
    print(m.get_info())

    print(b.make_sound())
    print(b.get_info())

if __name__ == "__main__":
    main()
